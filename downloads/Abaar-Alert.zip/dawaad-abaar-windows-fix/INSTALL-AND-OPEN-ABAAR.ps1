$ErrorActionPreference = "Stop"

$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageWeb = Join-Path $PackageRoot "web"
$TargetRoot = "C:\Users\EastG\agri-lab-dashboard"
$Port = 8765

if (-not (Test-Path $PackageWeb)) {
    throw "The package web folder is missing. Extract the complete ZIP before running this script."
}

if (-not (Test-Path $TargetRoot)) {
    New-Item -ItemType Directory -Path $TargetRoot -Force | Out-Null
}

$Targets = @()
if (Test-Path "$TargetRoot\web") {
    $Targets += "$TargetRoot\web"
}
if (Test-Path "$TargetRoot\app\web") {
    $Targets += "$TargetRoot\app\web"
}
if ($Targets.Count -eq 0) {
    New-Item -ItemType Directory -Path "$TargetRoot\web" -Force | Out-Null
    $Targets += "$TargetRoot\web"
}

$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
foreach ($TargetWeb in $Targets) {
    foreach ($Name in @("dashboard.html", "dawaad.html", "dawaad-map.js", "dawaad-map.css")) {
        $Existing = Join-Path $TargetWeb $Name
        if (Test-Path $Existing) {
            Copy-Item $Existing "$Existing.backup-$Stamp" -Force
        }
    }
    Copy-Item (Join-Path $PackageWeb "*") $TargetWeb -Recurse -Force
    Write-Host "Updated: $TargetWeb" -ForegroundColor Green
}

if (Test-Path "$TargetRoot\web\dawaad.html") {
    $ServeRoot = $TargetRoot
} elseif (Test-Path "$TargetRoot\app\web\dawaad.html") {
    $ServeRoot = "$TargetRoot\app"
} else {
    throw "Installation failed: dawaad.html was not copied."
}

$Dashboard = Join-Path $ServeRoot "web\dashboard.html"
$Dawaad = Join-Path $ServeRoot "web\dawaad.html"
if (-not (Select-String -Path $Dashboard -Pattern "Dawaad / Abaar Alert" -Quiet)) {
    throw "The updated dashboard marker is missing."
}
if (-not (Select-String -Path $Dawaad -Pattern "bing-key-form" -Quiet)) {
    throw "The updated Abaar page marker is missing."
}

# Stop only an older server already occupying this dedicated repair port.
try {
    $OldPids = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue |
        Select-Object -ExpandProperty OwningProcess -Unique
    foreach ($OldPid in $OldPids) {
        if ($OldPid -and $OldPid -ne $PID) {
            Stop-Process -Id $OldPid -Force -ErrorAction SilentlyContinue
        }
    }
} catch {
    # Get-NetTCPConnection is unavailable on some older PowerShell versions.
}

$Python = Get-Command py.exe -ErrorAction SilentlyContinue
if (-not $Python) {
    $Python = Get-Command python.exe -ErrorAction SilentlyContinue
}
if (-not $Python) {
    throw "Python was not found. Install Python or add py.exe to PATH."
}

$Server = Start-Process -FilePath $Python.Source `
    -ArgumentList @("-m", "http.server", "$Port", "--bind", "127.0.0.1") `
    -WorkingDirectory $ServeRoot -PassThru

$Url = "http://127.0.0.1:$Port/web/dashboard.html?build=3b437d9-$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())"
$Ready = $false
for ($Attempt = 1; $Attempt -le 12; $Attempt++) {
    Start-Sleep -Milliseconds 500
    try {
        $Response = Invoke-WebRequest -UseBasicParsing -Uri $Url -TimeoutSec 3
        if ($Response.StatusCode -eq 200 -and $Response.Content -match "Dawaad / Abaar Alert") {
            $Ready = $true
            break
        }
    } catch {}
}

if (-not $Ready) {
    Stop-Process -Id $Server.Id -Force -ErrorAction SilentlyContinue
    throw "The new web server did not start correctly."
}

Write-Host ""
Write-Host "GIS Engine and Dawaad / Abaar Alert are installed and verified." -ForegroundColor Green
Write-Host "Server PID: $($Server.Id)" -ForegroundColor Cyan
Write-Host "Opening: $Url" -ForegroundColor Cyan
Write-Host "Bing Satellite + Labels is under GIS Engine > Basemap and requires your Bing browser API key." -ForegroundColor Yellow
Start-Process $Url
