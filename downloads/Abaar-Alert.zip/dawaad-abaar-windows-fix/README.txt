GIS ENGINE + DAWAAD / ABAAR ALERT - WINDOWS UPDATE
Build: 3b437d9

1. Extract this entire ZIP file. Do not run it while it is still inside the ZIP viewer.
2. Double-click RUN-ABAAR.bat.
3. The installer updates C:\Users\EastG\agri-lab-dashboard, starts a fresh server on port 8765, verifies the files, and opens the main GIS Engine automatically.
4. If Windows asks for network permission for Python, allow private/local network access.

In the main GIS Engine left sidebar, open Basemap. Available choices include Esri World Imagery, Google Satellite, OpenStreetMap Standard, and Bing Satellite + Labels. Bing requires your own valid Bing Maps browser API key; paste it into the Bing field and press Save. Esri remains the default until a valid Bing key is saved.

Dawaad uses keyless Esri Satellite + Labels by default. The installer creates timestamped backups of existing dashboard and Dawaad files.
