DAWAAD / ABAAR ALERT - WINDOWS REPAIR PACKAGE
Build: 6fbf7e5

1. Extract this entire ZIP file. Do not run it while it is still inside the ZIP viewer.
2. Double-click RUN-ABAAR.bat.
3. The installer updates C:\Users\EastG\agri-lab-dashboard, starts a fresh server on port 8765, verifies the page, and opens Dawaad / Abaar Alert automatically.
4. If Windows asks for network permission for Python, allow private/local network access.

Esri Satellite + Labels is selected by default in Dawaad and requires no API key. OpenStreetMap Standard remains available in the Dawaad top-right layer selector and is now also available in the main GIS Engine Basemap panel.

The installer creates timestamped backups of existing dashboard and Dawaad files.
