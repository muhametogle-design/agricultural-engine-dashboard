VISIBLE DAWAAD / ABAAR ALERT UPDATE
Build: e98d5a1

1. Extract this ZIP completely.
2. Double-click RUN-ABAAR.bat.
3. A fresh server starts on port 8765 and opens Dawaad automatically.

VISIBLE CHANGES:
- Drought Monitoring / Kormeerka Abaaraha panel
- Sool, Nugaal, Sanaag, Togdheer and Mudug selector
- 10-day rainfall, anomaly, VCI and vegetation status
- climate station markers
- Functional, Stressed and Dry pastoral water-point markers
- local mock fallback, so indicators work with py -m http.server

Esri Satellite + Labels is selected by default and needs no API key.
