DAWAAD PASTORAL AGRO-HYDROLOGY UPDATE
Build: b444df9

1. Extract this ZIP completely.
2. Double-click RUN-ABAAR.bat.
3. A fresh server starts on port 8765 and opens Dawaad automatically.

VISIBLE FEATURES:
- Drought Monitoring / Kormeerka Abaaraha panel
- rainfall, anomaly, VCI, climate stations and water points
- collapsible Pastoral Utility Tools overlay on the map
- toggleable High Yield, Medium and Deep Saline aquifer screening zones
- solar pump calculator for daily m3 demand and TDH/well depth
- recommended pump kW, solar array kWp and runtime
- map-click fence/corridor tool with perimeter metres and reserve hectares
- local mock fallback for static py -m http.server use

Aquifer and monitoring values are clearly labeled mock/screening data. Verify engineering decisions with field surveys, VES, test drilling and qualified design.
